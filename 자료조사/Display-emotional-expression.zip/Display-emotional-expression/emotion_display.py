import pygame
import time
import os

WIDTH, HEIGHT = 800, 600
FPS = 5  # 이미지 표시 속도

# 숫자 입력에 따른 감정 매핑
EMOTION_MAP = {
    "1": ("손님을 만나 기쁨", "happy", "😊"),
    "2": ("명령을 받을 때 집중", "focused", "🧐"),
    "3": ("도와줄 수 없어 슬픔", "sad", "😢"),
    "4": ("모욕당해 울음", "crying", "😭"),
    "5": ("작별 인사", "goodbye", "👋"),
    "6": ("화남", "angry", "😠"),
    "7": ("혼란스러움", "confused", "😕"),
    "8": ("놀람", "surprised", "😲"),
    "9": ("흥분", "excited", "🥳"),
    "10": ("졸림", "sleepy", "😴"),
    "11": ("생각중", "thinking", "🤖")
}

def show_emotion_animation(emotion_folder, emotion_name, emoji, duration=3):
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("로봇 감정 애니메이션")

    frames = sorted([
        os.path.join(emotion_folder, f)
        for f in os.listdir(emotion_folder)
        if f.lower().endswith(".png")
    ])

    if not frames:
        print(f"{emotion_folder} 폴더에서 이미지를 찾을 수 없습니다.")
        return

    images = [pygame.image.load(f).convert_alpha() for f in frames]
    images = [pygame.transform.scale(img, (500, 500)) for img in images]

    font = pygame.font.SysFont(None, 36)
    clock = pygame.time.Clock()
    start_time = time.time()
    frame_index = 0
    running = True

    while running:
        screen.fill((255, 255, 255))  # 배경 흰색

        # 이미지 그리기
        screen.blit(images[frame_index], ((WIDTH - 500) // 2, (HEIGHT - 500) // 2))

        # 감정 이름 + 이모지 표시
        text = font.render(f"{emoji} {emotion_name}", True, (0, 0, 0))
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 30))

        pygame.display.flip()
        frame_index = (frame_index + 1) % len(images)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        clock.tick(FPS)

    pygame.quit()

# ====== 메인 실행 ======
if __name__ == "__main__":
    while True:
        print("\n감정을 선택하세요:")
        for key in sorted(EMOTION_MAP.keys(), key=int):
            name, _, emoji = EMOTION_MAP[key]
            print(f"{key}. {emoji} {name}")

        choice = input("숫자를 입력하세요 (종료하려면 q): ").strip()
        if choice == "q":
            break

        if choice in EMOTION_MAP:
            emotion_name, folder_name, emoji = EMOTION_MAP[choice]
            emotion_path = os.path.join("emotions", folder_name)
            show_emotion_animation(emotion_path, emotion_name, emoji, duration=4)
        else:
            print("잘못된 선택입니다. 다시 시도해주세요.")
