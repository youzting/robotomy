        # if time.time() - start_time > duration:
        #     running = False